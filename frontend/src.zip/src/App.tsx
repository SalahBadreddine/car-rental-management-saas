import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Index from "./pages/Index";
import ClientIndex from "./pages/Client/Index";
import SignIn from "./pages/SignIn";
import SignUp from "./pages/SignUp";
import VerifyEmail from "./pages/VerifyEmail";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Vehicles from "./pages/Vehicles";
import ClientVehicle from "./pages/Client/Vehicle";
import CarDetails from "./pages/CarDetails";
import ClientCarDetails from "./pages/Client/CarDetails";
import CompareCars from "./pages/CompareCars";
import RentCar from "./pages/RentCar";
import Payment from "./pages/Payment";
import ConfirmationCode from "./pages/ConfirmationCode";
import ReservationConfirmation from "./pages/ReservationConfirmation";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Profile from "./pages/Profile";
import EditProfile from "./pages/EditProfile";
import RentalPolicy from "./pages/RentalPolicy";
import NotFound from "./pages/NotFound";
import ProtectedRoute from "./components/ProtectedRoute";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>

          {/* Redirect root to sign in if not logged */}
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <ClientIndex />
              </ProtectedRoute>
            }
          />

          {/* Auth pages */}
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/verify-email" element={<VerifyEmail />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password" element={<ResetPassword />} />

          {/* Protected pages */}
          <Route
            path="/vehicles"
            element={
              <ProtectedRoute>
                {/* to be changed later  */}
                < ClientVehicle/>
              </ProtectedRoute>
            }
          />

          <Route
            path="/vehiclesClient"
            element={
              <ProtectedRoute>
                < ClientVehicle/>
              </ProtectedRoute>
            }
          />

          <Route
            path="/vehicles/:id"
            element={
              <ProtectedRoute>
                <CarDetails />
              </ProtectedRoute>
            }
          />

          <Route
            path="/vehiclesClient/:id"
            element={
              <ProtectedRoute>
                < ClientCarDetails/>
              </ProtectedRoute>
            }
          />

          <Route path="/compare" element={<CompareCars />} />
          <Route path="/rent/:id" element={<RentCar />} />
          <Route path="/rent/payment" element={<Payment />} />
          <Route path="/rent/confirm-code" element={<ConfirmationCode />} />
          <Route path="/rent/confirmation" element={<ReservationConfirmation />} />

          <Route
            path="/about"
            element={
              <ProtectedRoute>
                <About />
              </ProtectedRoute>
            }
          />

          <Route
            path="/contact"
            element={
              <ProtectedRoute>
                <Contact />
              </ProtectedRoute>
            }
          />

          <Route path="/profile" element={<Profile />} />
          <Route path="/profile/edit" element={<EditProfile />} />
          <Route path="/rental-policy" element={<RentalPolicy />} />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
